# Bolt.New React App

## Kurulum
```bash
npm install
```

## Yerelde Çalıştırma
```bash
npm run dev
```

## Netlify Deploy
1. Bu klasörü GitHub'a yükle.
2. Netlify'de **New Site from Git** seç.
3. Build Command: `npm run build`
4. Publish Directory: `dist`
5. Deploy et.
